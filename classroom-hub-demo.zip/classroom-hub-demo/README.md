# Classroom Hub — Demo API

API local simulada para probar Classroom Hub mientras se configura la conexión real con Google Classroom.

## Requisitos
Node.js 18 o superior.

## Iniciar
```bash
node server.js
```

Luego abre:
- http://localhost:8787/
- http://localhost:8787/v1/courses
- http://localhost:8787/v1/all

## Importante
Esta API NO se conecta a Google Classroom ni contiene datos reales. Solo sirve para pruebas.
La conexión real necesita OAuth y la API oficial de Google Classroom.
