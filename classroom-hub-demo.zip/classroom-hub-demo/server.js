const http = require("http");
const fs = require("fs");
const path = require("path");

const PORT = process.env.PORT || 8787;
const DATA = JSON.parse(fs.readFileSync(path.join(__dirname, "classroom-data.json"), "utf8"));

function send(res, code, body) {
  res.writeHead(code, {"Content-Type": "application/json; charset=utf-8"});
  res.end(JSON.stringify(body, null, 2));
}

const server = http.createServer((req, res) => {
  const url = new URL(req.url, `http://localhost:${PORT}`);
  const p = url.pathname;

  if (req.method !== "GET") return send(res, 405, {error:"Demo API: solo GET"});

  if (p === "/") return send(res, 200, {
    name:"Classroom Hub Demo API",
    mode:"DEMO",
    message:"API simulada para probar Classroom Hub sin datos reales de Google."
  });

  if (p === "/health") return send(res, 200, {ok:true, mode:"DEMO"});

  if (p === "/v1/courses") {
    return send(res, 200, {courses: DATA.courses});
  }

  const courseMatch = p.match(/^\/v1\/courses\/([^/]+)$/);
  if (courseMatch) {
    const course = DATA.courses.find(c => c.id === courseMatch[1]);
    return course ? send(res, 200, course) : send(res, 404, {error:"Course not found"});
  }

  const workMatch = p.match(/^\/v1\/courses\/([^/]+)\/courseWork$/);
  if (workMatch) {
    return send(res, 200, {
      courseWork: DATA.courseWork.filter(x => x.courseId === workMatch[1])
    });
  }

  const materialMatch = p.match(/^\/v1\/courses\/([^/]+)\/courseWorkMaterials$/);
  if (materialMatch) {
    return send(res, 200, {
      courseWorkMaterial: DATA.courseWorkMaterials.filter(x => x.courseId === materialMatch[1])
    });
  }

  if (p === "/v1/all") {
    return send(res, 200, DATA);
  }

  return send(res, 404, {
    error:"Not found",
    endpoints:[
      "GET /v1/courses",
      "GET /v1/courses/{courseId}",
      "GET /v1/courses/{courseId}/courseWork",
      "GET /v1/courses/{courseId}/courseWorkMaterials",
      "GET /v1/all"
    ]
  });
});

server.listen(PORT, () => {
  console.log(`Classroom Hub Demo API running at http://localhost:${PORT}`);
});
